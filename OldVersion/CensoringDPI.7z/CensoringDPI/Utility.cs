﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Net;
using System.IO;
using System.IO.Compression;
using System.Threading;
using System.Reflection;

using MahApps.Metro.Controls.Dialogs;
using MahApps.Metro.Controls;
using Octokit;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.Security.Principal;

namespace CensoringDPI
{
    class Utility
    {
        public static string CrashLogFilePath { get; } = @"Log\" + $"CrashLog_[{DateTime.Now:yyyy-MM-dd}]" +
                                                                   $"({DateTime.Now:hh-ss}).log";
        public static string LogFilePath { get; } = @"Log\" + $"Log_[{DateTime.Now:yyyy-MM-dd}]" +
                                                                   $"({DateTime.Now:hh-ss}).log";

        public static bool NeedUpdate = false;

        public static bool IsAdministrator()
        {
            WindowsIdentity identity = WindowsIdentity.GetCurrent();

            if (identity != null)
            {
                WindowsPrincipal principal = new WindowsPrincipal(identity);
                return principal.IsInRole(WindowsBuiltInRole.Administrator);
            }

            return false;
        }

        /// <summary>
        /// 새로운 메세지를 띄웁니다
        /// </summary>
        /// <param name="message">메세지 내용</param>
        /// <param name="waittime">메세지 창을 띄워둘 시간</param>
        public static void NewMessageWindow(string message, Window window, int waittime = 3000)
        {
            MessageWindow messageWindow = new MessageWindow(message, window, waittime);
            messageWindow.Show();
        }

        /// <summary>
        /// url에서 파일을 다운로드 합니다
        /// </summary>
        /// <param name="url">파일 Url</param>
        /// <param name="filename">다운로드한 파일을 저장할때 설정할 이름<br/>>파일 확장자는 자동으로 보정됩니다</param>
        public static void UrlDownload(string url, string filename)
        {
            WebClient webClient = new WebClient();
            string url_ext = url.Substring(url.Length - 4);
            if (!filename.EndsWith(url_ext))
            {
                filename += url_ext;
            }
            webClient.DownloadFile(url, @"Cache\" + filename);
            webClient.Dispose();
        }

        /// <summary>
        /// ZIP 파일 추출합니다
        /// </summary>
        /// <param name="zipFilePath">ZIP 파일 경로</param>
        /// <param name="backupFolder">백업 폴더</param>
        public static void ExtractZIPFile(string zipFilePath, string backupFolder)
        {
            if (!Directory.Exists(backupFolder))
            {
                Directory.CreateDirectory(backupFolder);
            }
            try
            {
                ZipFile.ExtractToDirectory(@"Cache\" + zipFilePath, backupFolder);
            }
            catch (System.IO.IOException)
            {
                Directory.Delete(backupFolder + @"\" + zipFilePath.Substring(0, zipFilePath.Length - 4), true);
                ExtractZIPFile(zipFilePath, backupFolder);
            }
        }

        /// <summary>
        /// 로그를 추가합니다
        /// </summary>
        /// <param name="path">로그파일 이름 또는 경로</param>
        /// <param name="contents">로그 내용</param>
        public static void AddLog(string contents) => Logging(LogFilePath, $"\n[LOG]\n[TIME][{DateTime.Now}]\n[COMMENT] {contents}\n[LOGEND]\n");

        private static void Logging(string path, string contents)
        {
            try
            {
                if (!Directory.Exists("Log"))
                    Directory.CreateDirectory("Log");
                File.AppendAllText(path, contents);
            }
            catch (Exception e)
            {
                File.AppendAllText(@"Log\[LogingCrash].log", $"\n[CrashLog]\n[TIME][{DateTime.Now}]\n[HEADER][로그 쓰기 오류]\n[Message] {e.Message}\n" +
                                                             $"\n[StackTrace]\n{e.StackTrace}" +
                                                             $"\n[InnerException] {e.InnerException}" +
                                                             $"\n[Source] {e.Source}" +
                                                             $"\n[Data] {e.Data}" +
                                                             $"\n[LOGEND]\n");
            }
        }

        /// <summary>
        /// 충돌 로그를 추가합니다
        /// </summary>
        /// <param name="fe">로그에 남길 예외</param>
        /// <param name="addheader">로그에 추가할 코멘트</param>
        public static void AddCrashLog(Exception fe, string addheader = "")
        {
            Logging(CrashLogFilePath, $"\n[CrashLog]\n[LOG]\n[TIME] [{DateTime.Now}]\n[HEADER]{addheader}\n[Message] {fe.Message}\n" +
                                      $"\n[StackTrace]\n{fe.StackTrace}" +
                                      $"\n[InnerException] {fe.InnerException}" +
                                      $"\n[Source] {fe.Source}" +
                                      $"\n[Data] {fe.Data}" +
                                      $"\n[LOGEND]\n");
        }

        /// <summary>
        /// 폴더 내부의 폴더와 파일을 절대경로 리스트로 반환합니다.<br/>
        /// 폴더가 존재하지 않을때는 <c>null</c>을 반환합니다.
        /// </summary>
        /// <param name="path">내부를 볼 폴더의 경로</param>
        /// <returns>문자열 리스트로 반환합니다</returns>
        public static List<string> GetFilelist(string path)
        {
            List<string> fileList = new List<string>();
            System.IO.DirectoryInfo di = new System.IO.DirectoryInfo(path);
            if (!di.Exists)
                return null;
            foreach (System.IO.DirectoryInfo directory in di.GetDirectories())
                fileList.Add(directory.FullName);
            foreach (System.IO.FileInfo file in di.GetFiles())
                fileList.Add(file.FullName);
            return fileList;
        }

        /// <summary>
        /// 현제 프로그램을 실행중인 운영체제가 64bit이면 true를 반환합니다
        /// </summary>
        public static bool Is64bit() => Environment.Is64BitOperatingSystem;

    }
}
