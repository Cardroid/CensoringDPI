﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MahApps.Metro.Controls;

namespace CensoringDPI
{
    public partial class DPISetting : MetroWindow
    {
        public DPISetting()
        {
            InitializeComponent();

            checkbox_StartandUpdate.IsChecked = Properties.Settings.Default.isStartUpdate;
            checkbox_StartandBypassCensorship.IsChecked = Properties.Settings.Default.isStartandRun;

            checkbox_StartandUpdate.Content = "시작시 Good Bye DPI 확인";
            checkbox_StartandBypassCensorship.Content = "시작시 자동 작동시작";
            button_passivityUpdate.Content = "Good Bye DPI 업데이트 확인";
            button_Manual.Content = "메뉴얼";
            button_info.Content = "정보";

            Radio_1.IsChecked = false;
            Radio_2.IsChecked = false;
            Radio_3.IsChecked = false;
            Radio_4.IsChecked = false;
            //Radio_1.ToolTip

            switch (Properties.Settings.Default.Arguments)
            {
                case -1:
                    Radio_1.IsChecked = true;
                    break;
                case -2:
                    Radio_2.IsChecked = true;
                    break;
                case -3:
                    Radio_3.IsChecked = true;
                    break;
                case -4:
                    Radio_4.IsChecked = true;
                    break;
            }
        }

        private void RadioButton_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as RadioButton;

            if (button == Radio_1)
                Properties.Settings.Default.Arguments = -1;
            if (button == Radio_2)
                Properties.Settings.Default.Arguments = -2;
            if (button == Radio_3)
                Properties.Settings.Default.Arguments = -3;
            if (button == Radio_4)
                Properties.Settings.Default.Arguments = -4;
            Properties.Settings.Default.Save();
        }

        private void Checkbox_Click(object sender, RoutedEventArgs e)
        {
            CheckBox btn = (CheckBox)sender;
            switch (btn.Name)
            {
                case "checkbox_StartandBypassCensorship":
                    if ((bool)checkbox_StartandBypassCensorship.IsChecked)
                        checkbox_StartandBypassCensorship.IsChecked = true;
                    else
                        checkbox_StartandBypassCensorship.IsChecked = false;
                    Properties.Settings.Default.isStartandRun = (bool)checkbox_StartandBypassCensorship.IsChecked;
                    break;
                case "checkbox_StartandUpdate":
                    if ((bool)checkbox_StartandUpdate.IsChecked)
                        checkbox_StartandUpdate.IsChecked = true;
                    else
                        checkbox_StartandUpdate.IsChecked = false;
                    Properties.Settings.Default.isStartUpdate = (bool)checkbox_StartandUpdate.IsChecked;
                    break;
            }
            Properties.Settings.Default.Save();
        }

        private void button_passivityUpdate_Click(object sender, RoutedEventArgs e)
        {
            Updater updater = new Updater();
            updater.ShowDialog();
        }

        private void button_Manual_Click(object sender, RoutedEventArgs e)
        {
            Manual manual = new Manual();
            manual.Show();
        }

        private void button_info_Click(object sender, RoutedEventArgs e)
        {
            Information information = new Information();
            information.Show();
        }
    }
}
