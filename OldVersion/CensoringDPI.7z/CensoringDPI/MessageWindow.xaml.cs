﻿using System;
using System.Timers;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using MahApps.Metro.Controls;
using System.Windows.Threading;

namespace CensoringDPI
{
    public partial class MessageWindow : MetroWindow
    {
        public Window window;
        public MessageWindow(string message, Window win, float waittime = 3000)
        {
            InitializeComponent();

            Message.Text = message;
            window = win;

            Brush brushOpacity = this.Background.Clone();

            brushOpacity.Opacity = 0;
            this.Background = brushOpacity;

            WaitClose((int)waittime);
            this.SizeToContent = SizeToContent.WidthAndHeight;

            this.Show();

            this.Left = window.Left + (window.Width / 2) - (this.Width / 2);
            this.Top = window.Top + window.Height;
        }
        private async void WaitClose(int waittime)
        {
            await Task.Delay(waittime);
            this.Close();
        }

        private void MetroWindow_Activated(object sender, EventArgs e)
        {
            window.Activate();
        }
    }
}