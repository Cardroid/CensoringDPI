﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Net;
using System.IO;
using System.IO.Compression;
using System.Threading;
using System.Reflection;

using MahApps.Metro.Controls.Dialogs;
using MahApps.Metro.Controls;
using Octokit;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using Hard;

namespace CensoringDPI
{
    public partial class MainWindow : MetroWindow
    {
        System.Windows.Forms.MenuItem item4 = new System.Windows.Forms.MenuItem();
        System.Windows.Forms.MenuItem item3 = new System.Windows.Forms.MenuItem();

        private static System.Windows.Forms.NotifyIcon notify = new System.Windows.Forms.NotifyIcon();
        private static bool DPIrun = false;

        public static string DPI_Path { private set; get; }
        private static Process DPI = new Process();

        private static Process[] isRuningProcess = Process.GetProcessesByName("CensoringDPI");

        public MainWindow()
        {
            if (isRuningProcess.Length > 1)
            {
                MessageBox.Show("이미 실행중입니다.", "실행 중인 프로그램 감지됨", MessageBoxButton.OK, MessageBoxImage.Information);
                DLLImport.SetForegroundWindow(isRuningProcess[0].MainWindowHandle);
                System.Windows.Application.Current.Shutdown();
            }
            else
            {
                InitializeComponent();

                if (Utility.Is64bit())
                    DPI_Path = @"DPI\x64\goodbyedpi.exe";
                else
                    DPI_Path = @"DPI\x32\goodbyedpi.exe";

                button_DPISetting.Content = "설정";
                buttonDPIrun.Content = "작동시작";
                buttonDPIstop.Content = "작동중지";

                //TextBolckLog.Visibility = Visibility.Collapsed;
                buttonDPIstop.IsEnabled = false;

                ID comid = new ID();
                string COMGUID = comid.CPU() + comid.HDD("C");

                if (Properties.Settings.Default.isStartUpdate)
                {
                    Updater updater = new Updater();
                    updater.ShowDialog();
                }
                else
                {
                    if (Properties.Settings.Default.computerGUID != COMGUID)
                    {
                        Manual manual = new Manual();
                        manual.Show();
                        Properties.Settings.Default.computerGUID = COMGUID;
                    }
                    else
                    {
                        DPI_Check();
                        if (Utility.NeedUpdate)
                            DPI_Check(true);
                    }
                }
            }
        }

        private void MainWindow_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
            {
                try { DPI.Kill(); }
                catch { }
                Properties.Settings.Default.Save();
                //catch (Win32Exception) { }
                //catch (Exception ex) { Utility.AddCrashLog(ex, "Good Bye DPI 종료 실패"); }
                System.Windows.Application.Current.Shutdown();
            }
            if (e.Key == Key.F11)
            {
                if (WindowState == WindowState.Maximized)
                    WindowState = WindowState.Normal;
                else
                    WindowState = WindowState.Maximized;
            }
            if (e.Key == Key.M)
            {
                if (this.WindowState == WindowState.Normal)
                    this.WindowState = WindowState.Maximized;
                else if (this.WindowState == WindowState.Maximized)
                    this.WindowState = WindowState.Normal;
            }
            if (e.Key == Key.N)
            {
                this.WindowState = WindowState.Minimized;
            }
        }

        private void DPI_Check(bool needupdate = false)
        {
            if (!needupdate)
            {
                if (!Directory.Exists("DPI"))
                {
                    Utility.NewMessageWindow("Good Bye DPI 가 없는 것 같습니다.\nGood Bye DPI 다운로드가 필요합니다.", this);
                    Utility.NeedUpdate = true;
                }
                else if (!File.Exists(@"DPI\Ver.txt"))
                {
                    Utility.NewMessageWindow("Good Bye DPI 버전을 감지하지 못했습니다.", this);
                    Utility.NeedUpdate = true;
                }
            }
            else
            {
                Manual manual = new Manual();
                manual.Show();
            }
        }

        private void DPI_Process_Setup()
        {
            DPI.StartInfo.FileName = DPI_Path;
            DPI.StartInfo.Arguments = Properties.Settings.Default.Arguments.ToString();
            DPI.StartInfo.UseShellExecute = true;
            DPI.StartInfo.RedirectStandardOutput = true;
            DPI.StartInfo.RedirectStandardError = true;
            DPI.StartInfo.CreateNoWindow = true;
            DPI.StartInfo.Verb = "runas";
        }

        private void buttonDPI_Click(object sender, RoutedEventArgs e)
        {
            var button = (Button)sender;

            if (button == buttonDPIrun)
                DPI_Run();
            else if (button == buttonDPIstop)
                DPI_Stop();
        }

        private void DPI_Run()
        {
            if (!DPIrun)
            {
                if (!File.Exists(DPI_Path))
                {
                    Utility.NewMessageWindow("Good Bye DPI가 없습니다!", this);
                    Manual manual = new Manual();
                    manual.Show();
                    return;
                }
                item3.Enabled = false;
                DPIrun = true;

                DPI_Process_Setup();
                //DPI.OutputDataReceived += new DataReceivedEventHandler(DPI_OutputDataReceived1);
                //DPI.ErrorDataReceived += new DataReceivedEventHandler(DPI_OutputDataReceived1);

                buttonDPIrun.IsEnabled = false;
                buttonDPIstop.IsEnabled = true;
                button_DPISetting.IsEnabled = false;
                //TextBolckLog.Visibility = Visibility.Visible;

                try
                { 
                    DPI.Start();
                    item4.Text = "작동종료";
                }
                catch (Win32Exception) { }
                catch (Exception ex)
                {
                    Utility.AddCrashLog(ex, "Good Bye DPI 시작 실패");
                    buttonDPIrun.IsEnabled = true;
                    buttonDPIstop.IsEnabled = false;
                    button_DPISetting.IsEnabled = true;
                    DPIrun = false;
                    //TextBolckLog.Visibility = Visibility.Collapsed;
                }
                //DPI.BeginErrorReadLine();
                //DPI.BeginOutputReadLine();
            }
        }

        private void DPI_Stop()
        {
            if (DPIrun)
            {
                item3.Enabled = true;
                DPIrun = false;

                buttonDPIrun.IsEnabled = true;
                buttonDPIstop.IsEnabled = false;
                button_DPISetting.IsEnabled = true;
                //TextBolckLog.Visibility = Visibility.Collapsed;
                //DPI.CancelOutputRead();
                //DPI.CancelErrorRead();
                try { DPI.Kill(); }
                catch (Win32Exception) { }
                catch (Exception ex) { Utility.AddCrashLog(ex, "Good Bye DPI 종료 실패"); }
                item4.Text = "작동시작";
            }
        }

        //private void DPI_OutputDataReceived1(object sender, DataReceivedEventArgs e)
        //{
        //    TextBolckLog.Text = e.Data;
        //}

        private void button_DPISetting_Click(object sender, RoutedEventArgs e)
        {
            DPISetting dPISetting = new DPISetting();
            dPISetting.ShowDialog();
        }

        private void MainWindow_Closing(object sender, CancelEventArgs e)
        {
            e.Cancel = true;
            this.Visibility = Visibility.Collapsed;
            this.Hide();
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            System.Windows.Forms.ContextMenu menu = new System.Windows.Forms.ContextMenu();

            System.Windows.Forms.MenuItem item1 = new System.Windows.Forms.MenuItem();
            System.Windows.Forms.MenuItem item2 = new System.Windows.Forms.MenuItem();
            menu.MenuItems.Add(item1);
            menu.MenuItems.Add(item2);
            menu.MenuItems.Add(item3);
            menu.MenuItems.Add(item4);
            item1.Index = 3;
            item1.Text = "프로그램 종료";
            item1.Click += delegate (object click, EventArgs eClick)
            {
                DPI_Stop();
                Properties.Settings.Default.Save();
                //catch (Win32Exception) { }
                //catch (Exception ex) { Utility.AddCrashLog(ex, "Good Bye DPI 종료 실패"); }
                System.Windows.Application.Current.Shutdown();
            };
            item2.Index = 2;
            item2.Text = "프로그램 열기";
            item2.Click += delegate (object click, EventArgs eClick)
            {
                this.Visibility = Visibility.Visible;
                this.Activate();
                this.SizeToContent = SizeToContent.WidthAndHeight;
                this.Left = SystemParameters.WorkArea.Width / 2 - this.Width / 2;
                this.Top = SystemParameters.WorkArea.Height / 2 - this.Height / 2;
                this.WindowState = WindowState.Normal;
                this.Focus();
            };
            item3.Index = 1;
            item3.Text = "설정";
            item3.Click += delegate (object click, EventArgs eClick)
            {
                DPISetting dPISetting = new DPISetting();
                dPISetting.ShowDialog();
            };
            item4.Index = 0;
            item4.Text = "작동시작";
            item4.Click += delegate (object click, EventArgs eClick)
            {
                if (DPIrun)
                    DPI_Stop();
                else
                    DPI_Run();
            };
            notify.Icon = Properties.Resources.icon;
            notify.DoubleClick += delegate (object senders, EventArgs args)
            {
                this.Visibility = Visibility.Visible;
                this.Activate();
                this.SizeToContent = SizeToContent.WidthAndHeight;
                this.Left = SystemParameters.WorkArea.Width / 2 - this.Width / 2;
                this.Top = SystemParameters.WorkArea.Height / 2 - this.Height / 2;
                this.WindowState = WindowState.Normal;
                this.Focus();
            };
            notify.ContextMenu = menu;
            notify.Text = "CensoringDPI";
            notify.Visible = true;

            //this.Hide();
            this.Visibility = Visibility.Collapsed;
        }
    }
}