﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Net;
using System.IO;
using System.IO.Compression;
using System.Threading;
using System.Reflection;

using MahApps.Metro.Controls.Dialogs;
using MahApps.Metro.Controls;
using Octokit;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;

namespace CensoringDPI
{
    public partial class Updater : MetroWindow
    {
        #region Good Bye DPI 업데이트 관련 변수
        private static BackgroundWorker BgUpdate = new BackgroundWorker() { WorkerReportsProgress = true, WorkerSupportsCancellation = true };

        private static bool BgUpdate_Wait = false;
        private static int UpdateComplete = -1;
        #endregion

        public static string CrashLogFilePath => Utility.CrashLogFilePath;

        public Updater()
        {
            InitializeComponent();

            #region 캐시폴더 생성
            if (Directory.Exists("Cache"))
            {
                Directory.Delete("Cache", true);
            }
            Directory.CreateDirectory("Cache");
            #endregion
            #region 초기 상태 정의

            BgUpdate.DoWork += DPI_UpdateCheck;
            BgUpdate.ProgressChanged += BgUpdate_ProgressChanged;
            BgUpdate.RunWorkerCompleted += BgUpdate_RunWorkerCompleted;

            ProgressBarMain.Minimum = 0;
            ProgressBarMain.Maximum = 100;

            LabelTitle.Content = "Good Bye DPI 업데이트 시작";
            LabelContent.Content = "잠시 후 다운로드가 시작됩니다";

            #endregion

            BgUpdate.RunWorkerAsync();
        }

        #region 업데이트 관련

        private async void BgUpdate_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            #region 작업 진행율 동기화
            if (e.ProgressPercentage >= 0 && e.ProgressPercentage <= 100)
            {
                LabelTitle.Content = ("Good Bye DPI 업데이트 중...");
                if (e.ProgressPercentage != 0)
                {
                    ProgressBarMain.IsIndeterminate = false;
                    for (int i = (int)ProgressBarMain.Value; i < e.ProgressPercentage; i++)
                    {
                        await Task.Delay(30);
                        ProgressBarMain.Value = i;
                    }
                }
                switch (e.ProgressPercentage)
                {
                    case 0:
                        ProgressBarMain.IsIndeterminate = true;
                        ProgressBarMain.Value = 0;
                        LabelContent.Content = "초기화 중...";
                        await Task.Delay(1000);
                        break;
                    case 5:
                        LabelContent.Content = "현재 버전을 학인 중...";
                        break;
                    case 10:
                    case 25:
                        LabelContent.Content = "최신버전 확인 중...";
                        break;
                    case 30:
                        LabelContent.Content = "파일 다운로드 중...";
                        break;
                    case 65:
                        LabelContent.Content = "압축 푸는 중...";
                        break;
                    case 80:
                        LabelContent.Content = "실행파일 추출 중...";
                        break;
                    case 90:
                        LabelContent.Content = "버전정보 갱신 중...";
                        break;
                    case 100:
                        LabelContent.Content = "완료 중...";
                        break;
                }
            }
            #endregion
            #region 강제 다운로드
            if (e.ProgressPercentage > 100)
            {
                switch (e.ProgressPercentage)
                {
                    case 101:
                        var new_version = await this.ShowMessageAsync("Good Bye DPI 최신버전 발견",
                                                                      "다운로드 하시겠습니까?",
                                                                      MessageDialogStyle.AffirmativeAndNegative);
                        if (new_version == MessageDialogResult.Negative)
                        {
                            Utility.AddLog($"\n[LOG]\n[TIME] [{DateTime.Now.ToString()}]\n[HEADER] TaskCanceledbyUser\n[Message] 사용자가 작업을 취소했습니다.\n[LOGEND]\n");
                            BgUpdate.CancelAsync();
                            break;
                        }
                        break;
                    case 102:
                        var old_version = await this.ShowMessageAsync("이미 Good Bye DPI가 최신버전입니다",
                                                                      "강제로 업데이트 하시겠습니까?",
                                                                      MessageDialogStyle.AffirmativeAndNegative);
                        if (old_version == MessageDialogResult.Negative)
                        {
                            Utility.AddLog($"\n[LOG]\n[TIME] [{DateTime.Now.ToString()}]\n[HEADER] TaskCanceledbyUser\n[Message] 사용자가 작업을 취소했습니다.\n[LOGEND]\n");
                            BgUpdate.CancelAsync();
                            break;
                        }
                        break;
                }
            }
            #endregion
            #region 예외 처리
            if (e.ProgressPercentage < 0) //오류 처리
            {
                switch (e.ProgressPercentage)
                {
                    case -1:
                        var releaseserror = await this.ShowMessageAsync("오류가 발생했습니다.",
                                                $"자세한 오류 내용 : {sender.ToString()} \n다시 시도 하시겠습니까?",
                                                MessageDialogStyle.AffirmativeAndNegative);
                        if (releaseserror == MessageDialogResult.Affirmative)
                        {
                            BgUpdate.Dispose();
                            BgUpdate.RunWorkerAsync();
                            break;
                        }
                        else
                        {
                            await this.ShowMessageAsync("Good Bye DPI 업데이트 실패", "자세한 오류 내역은 로그를 확인하십시오.");
                            BgUpdate.CancelAsync();
                            break;
                        }
                }
            }
            #endregion
            lock (this) { BgUpdate_Wait = false; }
        }

        private async void DPI_Update_Canceled(object sender, EventArgs e)
        {
            if (BgUpdate.IsBusy || BgUpdate != null)
                BgUpdate.Dispose();
            ProgressBarMain.IsIndeterminate = true;
            LabelTitle.Content = "Good Bye DPI 업데이트 취소됨";
            LabelContent.Content = "사용자가 작업을 중단했습니다.";
            await Task.Delay(3000);
            this.Close();
        }

        private async void BgUpdate_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (BgUpdate.IsBusy || BgUpdate != null)
                BgUpdate.Dispose();
            if (UpdateComplete == 1)
            {
                DPI_Update_Canceled(sender, e);
                return;
            }
            else if (e.Error != null)
            {
                Utility.AddCrashLog(e.Error, "작업 중 오류 발생");
                LabelTitle.Content = "Good Bye DPI 업데이트 실패";
                LabelContent.Content = $"자세한 오류 내용 : {e.Error.Message}";
            }
            else if (UpdateComplete == 0)
            {
                Utility.AddLog("Good Bye DPI 업데이트 완료");
                ProgressBarMain.Value = 100;
                LabelTitle.Content = "Good Bye DPI 업데이트 완료";
                LabelContent.Content = "Good Bye DPI 업데이트를 성공적으로 완료하였습니다.";
            }
            else if (UpdateComplete == -1)
            {
                LabelTitle.Content = "Good Bye DPI 업데이트 실패";
                LabelContent.Content = "자세한 오류 내역은 로그를 확인하십시오.";
            }
            else if (UpdateComplete == 2)
            {
                LabelTitle.Content = "Good Bye DPI 업데이트 불완전한 완료";
                LabelContent.Content = "사용에는 문제가 없으나, 오류가 발생했습니다.\n" +
                                       "자세한 오류 내역은 로그를 확인하십시오.";
            }
            await Task.Delay(3000);
            this.Close();
        }

        /// <summary>
        /// Good Bye DPI 업데이트 체크
        /// </summary>
        private void DPI_UpdateCheck(object sender, DoWorkEventArgs worke)
        {
            lock (this) { UpdateComplete = -1; }
            WorkThreadWait(0);
            if (BgUpdate.CancellationPending)
            {
                UpdateComplete = 1;
                return;
            }

            #region 초기 변수 정의
            var client = new GitHubClient(new ProductHeaderValue("CensoringDPI"));

            string ver;
            string latest = "";
            string filename = "";
            string downloadver = "?";
            Task<Release> releases;
            #endregion

            WorkThreadWait(5);
            if (BgUpdate.CancellationPending)
            {
                UpdateComplete = 1;
                return;
            }

            #region 현재 버전 확인
            try
            {
                ver = File.ReadAllText(@"DPI\Ver.txt");
            }
            catch (DirectoryNotFoundException) { ver = ""; }
            catch (FileNotFoundException) { ver = ""; }
            #endregion

            WorkThreadWait(10);
            if (BgUpdate.CancellationPending)
            {
                UpdateComplete = 1;
                return;
            }

            #region 최신버전 확인
            for (int ua = 0; ua < 1; ++ua)
            {
                Exception apierror = null;
                try
                {
                    releases = client.Repository.Release.GetLatest("ValdikSS", "GoodbyeDPI");
                    if (releases == null || releases.IsFaulted || releases.Exception != null)
                        throw new ArgumentNullException();

                    downloadver = releases.Result.TagName;

                    latest = releases.Result.Assets[0].BrowserDownloadUrl;
                    filename = releases.Result.Assets[0].Name;
                }
                catch (NotFoundException e)
                {
                    apierror = e;
                }
                catch (ApiException e)
                {
                    apierror = e;
                }
                catch (ArgumentNullException e)
                {
                    apierror = e;
                }
                catch (AggregateException e)
                {
                    apierror = e.InnerException;
                }

                if (apierror != null)
                {
                    Utility.AddCrashLog(apierror, "최신 릴리스 확인 : FAIL");
                    BgUpdate.ReportProgress(-1, apierror.Message);
                    return;
                }
            }
            #endregion

            WorkThreadWait(25);
            if (BgUpdate.CancellationPending)
            {
                UpdateComplete = 1;
                return;
            }

            #region Good Bye DPI 강제 업데이트 묻기
            lock (this) { BgUpdate_Wait = true; }
            if (ver != downloadver)
                BgUpdate.ReportProgress(101);
            else
                BgUpdate.ReportProgress(102);
            for (int w = 0; w < 1; ++w)
            {
                Thread.Sleep(200);
                if (BgUpdate_Wait)
                    w--;
            }
            if (BgUpdate.CancellationPending)
            {
                UpdateComplete = 1;
                return;
            }

            #endregion

            WorkThreadWait(30);
            if (BgUpdate.CancellationPending)
            {
                UpdateComplete = 1;
                return;
            }

            #region 파일 다운로드
            for (int ud = 0; ud < 1; ++ud)
            {
                try
                {
                    Utility.UrlDownload(latest, filename);
                }
                catch (Exception e)
                {
                    Utility.AddCrashLog(e, "파일 다운로드 : FAIL");
                    BgUpdate.ReportProgress(-1, e.Message);
                    return;
                }
            }
            #endregion

            WorkThreadWait(65);
            if (BgUpdate.CancellationPending)
            {
                UpdateComplete = 1;
                return;
            }

            #region 압축 해제
            for (int uz = 0; uz < 1; ++uz)
            {
                try
                {
                    Utility.ExtractZIPFile(filename, "DPI");
                }
                catch (Exception e)
                {
                    Utility.AddCrashLog(e, "압축 해제 : FAIL");
                    BgUpdate.ReportProgress(-1, e.Message);
                    return;
                }
            }
            #endregion

            WorkThreadWait(80);
            if (BgUpdate.CancellationPending)
            {
                UpdateComplete = 1;
                return;
            }

            #region 실행파일 추출
            try
            {
                List<string> downloadedDPIfilelist = Utility.GetFilelist(@"DPI\" + filename.Substring(0, filename.LastIndexOf('.')));
                if (downloadedDPIfilelist == null)
                {
                    Utility.AddCrashLog(new ArgumentNullException(), "실행 파일 추출에 실패했습니다");
                    lock (this) { UpdateComplete = -1; }
                    return;
                }
                foreach (string df in downloadedDPIfilelist)
                {
                    if (df.Contains("64") || df.Contains("32") || df.Contains("86"))
                    {
                        DirectoryInfo DPIexedirectory = new DirectoryInfo(df);
                        if (DPIexedirectory.Exists)
                        {
                            if (DPIexedirectory.Name.Contains("64"))
                            {
                                if (Directory.Exists(@"DPI\" + "x64"))
                                    Directory.Delete(@"DPI\" + "x64", true);
                                DPIexedirectory.MoveTo(@"DPI\" + "x64");
                                continue;
                            }
                            else if (DPIexedirectory.Name.Contains("32") || DPIexedirectory.Name.Contains("86"))
                            {
                                if (Directory.Exists(@"DPI\" + "x32"))
                                    Directory.Delete(@"DPI\" + "x32", true);
                                DPIexedirectory.MoveTo(@"DPI\" + "x32");
                                continue;
                            }
                        }
                    }
                    if (File.Exists(df))
                        File.Delete(df);
                    if (Directory.Exists(df))
                        Directory.Delete(df, true);
                }
                if (Directory.Exists(@"DPI\" + filename.Substring(0, filename.LastIndexOf('.'))))
                    Directory.Delete(@"DPI\" + filename.Substring(0, filename.LastIndexOf('.')), true);
            }
            catch (Exception e)
            {
                Utility.AddCrashLog(e, "실행 파일 추출 : FAIL");
                BgUpdate.ReportProgress(-1, e.Message);
                return;
            }
            #endregion

            WorkThreadWait(90);
            if (BgUpdate.CancellationPending)
            {
                UpdateComplete = 1;
                return;
            }

            #region 버전 정보 업데이트
            try
            {
                File.WriteAllText(@"DPI\Ver.txt", downloadver);
            }
            catch (Exception e)
            {
                Utility.AddCrashLog(e, "버전 정보 업데이트 : FAIL");
                BgUpdate.ReportProgress(-1, e.Message);
                return;
            }
            #endregion

            WorkThreadWait(100);
            lock (this) { UpdateComplete = 0; }
        }

        private void WorkThreadWait(int Progress, int delaytime = 200)
        {
            lock (this) { BgUpdate_Wait = true; }
            BgUpdate.ReportProgress(Progress);
            for (int w = 0; w < 1; ++w)
            {
                Thread.Sleep(delaytime);
                if (BgUpdate_Wait)
                    w--;
            }
        }
        #endregion

        private void Updater_Closing(object sender, CancelEventArgs e)
        {
            try
            {
                Properties.Settings.Default.Save();
                if (BgUpdate.IsBusy || BgUpdate != null)
                    BgUpdate.Dispose();
                if (Directory.Exists("Cache"))
                    Directory.Delete("Cache", true);
            }
            catch (Exception de)
            {
                Utility.AddCrashLog(de, "DPI 업데이터 정상 종료 실패");
            }
        }
    }
}
