﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MahApps.Metro.Controls;

namespace CensoringDPI
{
    public partial class Manual : MetroWindow
    {
        private bool DefaultManual = true;

        public Manual()
        {
            InitializeComponent();

            button_passivityUpdate.Content = "Good Bye DPI 다운로드";
            button_Switchdescription.Content = "자세한 설명 보기";

            LabelUpdateManual.Content = "이 프로그램은 Good Bye DPI를 사용합니다.\n" +
                                        "따라서 최초실행시 Good Bye DPI 다운로드가 필요합니다.\n" +
                                        "아래 버튼을 누르면 자동으로 다운로드를 시작합니다.";

            LabelManual.Content = "본 프로그램은 GoodByeDPI가 CLI기반이라 사용하기 어려워 하시는 분들을 위해 만들었습니다.\n\n" +
                                  "사용에 지장이 없으면 기본으로 설정되어 있는 값을 사용하시면 됩니다\n" +
                                  " -1 옵션 부터 -3 까지 써보시면서 가장 빠른 것을 선택 하시면 됩니다.\n" +
                                  " -4 옵션이 가장 빠르지만 국내 SNI검열에 대응할 수 없습니다.\n\n" +
                                  " -1      가장 호환성 높은 방식, 가장 느림.기본값.\n" +
                                  " -2      HTTPS의 속도가 더 빠르지만 여전히 호환성 높음.\n" +
                                  " -3      HTTPS 속도가 더 빠르며, HTTP 파편화를 진행하지 않음.\n" +
                                  " -4      가장 빠름";

            LabelManualOption.Visibility = Visibility.Collapsed;
            LabelManualdescription.Visibility = Visibility.Collapsed;

            LabelManualOption.Content = " -p\n" +
                                        " -r\n" +
                                        " -s\n" +
                                        " -m\n" +
                                        " -f [value]\n" +
                                        " -k [value]\n" +
                                        " -n\n" +
                                        " -e [value]\n" +
                                        " -a\n" +
                                        " -w\n" +
                                        " --port [value]\n" +
                                        " --ip-id [value]\n\n" +

                                        " --dns-addr [value]\n" +
                                        " --dns-port [value]\n" +
                                        " --dnsv6-addr [value]\n" +
                                        " --dnsv6-port [value]\n" +
                                        " --dns-verb\n" +
                                        " --blacklist [txtfile]\n\n" +

                                        " --set-ttl [value]\n\n" +

                                        " --wrong-chksum\n\n\n" +

                                        " -1 (-p -r -s -f 2 -k 2 -n -e 2)\n" +
                                        " -2 (-p -r -s -f 2 -k 2 -n -e 40)\n" +
                                        " -3 (-p -r -s -e 40)\n" +
                                        " -4 (-p -r -s)";

            LabelManualdescription.Content = "패시브 DPI 차단\n" +
                                             "호스트를 [hoSt]로 교체\n" +
                                             "host 헤더의 빈칸 제거\n" +
                                             "Host 헤더를 섞기(test.com->tEsT.cOm)\n" +
                                             "설정값에 맞춰서 HTTP 패킷을 쪼갭니다.작은 값을 수록 더 많이 쪼개집니다.\n" +
                                             "HTTP 지속성(keep-alive)패킷을 쪼갭니다. 작은 값을 수록 더 많이 쪼개집니다.\n" +
                                             "-k가 활성화된 경우 첫 번째 세그먼트 ACK 대기 안 함\n" +
                                             "설정값에 맞춰서 HTTPS 패킷을 쪼갭니다.작은 값을 수록 더 많이 쪼개집니다.\n" +
                                             "Method와 Request-URI 사이의 추가 공간(-s 사용 가능, 사이트를 손상시킬 수 있음)\n" +
                                             "모든 처리된 포트에서 HTTP 트래픽을 찾아 구문 분석(포트 80에만 해당하지 않음)\n" +
                                             "조각화를 수행할 추가 TCP 포트(및 - w를 사용한 HTTP 트릭)\n" +
                                             "추가 IP ID 처리(십진수, 이 ID를 사용하여 리디렉션 및 TCP RST를 Drop하십시오).\n" +
                                             "이 옵션은 여러 번 사용할 수 있음.\n" +
                                             "제공된 IP 주소로 UDP DNS 요청 리디렉션(실험적 기능)\n" +
                                             "제공된 포트로 UDP DNS 요청 재연결(기본값은 53번)\n" +
                                             "제공된 IPv6 주소로 UDPv6 DNS 요청 리디렉션(실험적 기능)\n" +
                                             "제공된 포트로 UDPv6 DNS 요청 재연결(기본값은 53번)\n" +
                                             "자세한 DNS 리디렉션 메시지 인쇄\n" +
                                             "호스트 이름 및 하위 도메인에 대해서만 HTTP 트릭 수행\n" +
                                             "텍스트 파일로 입력가능, 이 옵션은 여러 번 사용할 수 있음.\n" +
                                             "Fake Request Mode를 활성화하고 제공된 TTL[value]으로 보냅니다.\n" +
                                             "위험! 예기치 않은 방식으로 웹 사이트를 손상시킬 수 있습니다. 주의해서 사용하십시오.\n" +
                                             "Fake Request Mode를 활성화하고 잘못된 TCP 체크섬과 함께 출력.\n" +
                                             "VM 또는 일부 라우터에서는 작동하지 않을 수 있지만 set - ttl보다 안전합니다.\n\n" +

                                             "가장 호환성 높은 방식, 가장 느림.기본값.\n" +
                                             "HTTPS의 속도가 더 빠르지만 여전히 호환성 높음.\n" +
                                             "HTTPS 속도가 더 빠르며, HTTP 파편화를 진행하지 않음.\n" +
                                             "가장 빠름";
        }

        private void button_passivityUpdate_Click(object sender, RoutedEventArgs e)
        {
            Updater updater = new Updater();
            updater.ShowDialog();
        }

        private void button_Switchdescription_Click(object sender, RoutedEventArgs e)
        {
            if (DefaultManual)
            {
                DefaultManual = false;
                StackPanelUpdater.Visibility = Visibility.Collapsed;

                button_Switchdescription.Content = "기본 설명 보기";

                LabelManual.Content = "해당 설명은 기계번역이 포함되어 있습니다.\n" +
                                      "명령줄 수동 입력 옵션은 업데이트 예정입니다.";

                LabelManualOption.Visibility = Visibility.Visible;
                LabelManualdescription.Visibility = Visibility.Visible;
            }
            else
            {
                DefaultManual = true;
                StackPanelUpdater.Visibility = Visibility.Visible;

                LabelManualOption.Visibility = Visibility.Collapsed;
                LabelManualdescription.Visibility = Visibility.Collapsed;

                button_Switchdescription.Content = "자세한 설명 보기";

                LabelManual.Content = "본 프로그램은 GoodByeDPI가 CLI기반이라 사용하기 어려워 하시는 분들을 위해 만들었습니다.\n\n" +
                                      "사용에 지장이 없으면 기본으로 설정되어 있는 값을 사용하시면 됩니다\n" +
                                      " -1 옵션 부터 -3 까지 써보시면서 가장 빠른 것을 선택 하시면 됩니다.\n" +
                                      " -4 옵션이 가장 빠르지만 국내 SNI검열에 대응할 수 없습니다.\n\n" +
                                      " -1      가장 호환성 높은 방식, 가장 느림.기본값.\n" +
                                      " -2      HTTPS의 속도가 더 빠르지만 여전히 호환성 높음.\n" +
                                      " -3      HTTPS 속도가 더 빠르며, HTTP 파편화를 진행하지 않음.\n" +
                                      " -4      가장 빠름";
            }
        }

        private void MetroWindow_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            this.Left = ((SystemParameters.PrimaryScreenWidth) / 2) - (this.Width / 2);
            this.Top = ((SystemParameters.PrimaryScreenHeight) / 2) - (this.Height / 2);
        }
    }
}
