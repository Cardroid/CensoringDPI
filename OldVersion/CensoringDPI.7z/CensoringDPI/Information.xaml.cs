﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MahApps.Metro.Controls;

namespace CensoringDPI
{
    public partial class Information : MetroWindow
    {
        private static readonly string Version = Assembly.GetExecutingAssembly().GetName().Version.ToString();

        public Information()
        {
            InitializeComponent();

            AppName.Content = Assembly.GetExecutingAssembly().GetName().Name.ToString();
            AppVer.Content = Version;
            Madeby.Content = "Made by CarbonSIX";
            GithubUrl.Content = "Github of CarbonSIX";
            Thanks.Content = "Thanks for ValdikSS";
            ThanksGithubUrl.Content = "Github of ValdikSS";
        }

        private void GithubUrl_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Label label = (Label)sender;

            if (e.LeftButton == MouseButtonState.Pressed)
            {
                if (label == ThanksGithubUrl)
                    Process.Start("https://github.com/ValdikSS/GoodbyeDPI");
                if (label == GithubUrl)
                    Process.Start("https://github.com/Cardroid/CensoringDPI");
            }
        }
    }
}
